import java.util.Random;
import java.util.Scanner;

public class DiceRollerDAA {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random rand = new Random();

        System.out.print("Enter number of dice rolls: ");
        int rolls;
        while (true) {
            if (scanner.hasNextInt()) {
                rolls = scanner.nextInt();
                if (rolls > 0) break;
                else System.out.print("Please enter a positive number: ");
            } else {
                System.out.print("Invalid input. Enter an integer: ");
                scanner.next(); 
            }
        }

        int[] freq = new int[7]; 

        long startTime = System.nanoTime();

        for (int i = 0; i < rolls; i++) {
            int result = rand.nextInt(6) + 1;
            freq[result]++;
        }

        long endTime = System.nanoTime();

        System.out.println("\nResults after " + rolls + " rolls:");
        for (int i = 1; i <= 6; i++) {
            System.out.println("Face " + i + ": " + freq[i] + " times");
        }

        double timeTaken = (endTime - startTime) / 1e6;
        System.out.printf("\nTime taken: %.2f milliseconds\n", timeTaken);

        scanner.close();
    }
}
